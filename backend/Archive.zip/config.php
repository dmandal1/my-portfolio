<?php
/**
 * config.php — generated automatically by the installer.
 *
 * ┌──────────────────────────────────────────────────────────┐
 * │  DO NOT upload this file to Hostinger.                   │
 * │  Visit your site, complete the setup wizard, and the     │
 * │  installer will write this file with your real details.  │
 * └──────────────────────────────────────────────────────────┘
 *
 * If you need to reset the installer:
 *   1. Delete  public_html/installed.lock
 *   2. Delete  public_html/api/config.php
 *   3. Visit   https://yourdomain.com  and run setup again.
 */

// This placeholder file should never reach production.
// The real config.php is written by install.php.
http_response_code(503);
header('Content-Type: application/json');
echo json_encode(['error' => 'Site not configured. Please run the installer.']);
exit;
